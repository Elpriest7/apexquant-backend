# APEX QUANT — Backend Deployment Guide
# ═══════════════════════════════════════

## FILES IN THIS FOLDER
```
apexquant-backend/
├── server.js              ← Main server (Express + WebSocket)
├── package.json           ← Dependencies
├── .env.example           ← Copy this to .env and fill in keys
├── .gitignore
└── services/
    ├── marketData.js      ← Fetches real prices (CoinGecko, Twelve Data)
    ├── signalEngine.js    ← Finds high-probability trade setups
    └── journalStore.js    ← Stores all trades in memory
```

---

## STEP 1A — Create GitHub Repository

1. Go to github.com → Sign up free
2. Click the green "New" button (top left)
3. Name it: apexquant-backend
4. Set to Public
5. Click "Create repository"

---

## STEP 1B — Upload Files to GitHub

Option A (easiest on phone):
1. Open your new repo on GitHub
2. Click "Add file" → "Upload files"
3. Upload ALL files in this folder
4. For the services/ folder: create it first by naming a file "services/marketData.js"
5. Click "Commit changes"

Option B (if you have a computer):
```bash
git init
git add .
git commit -m "Initial APEX QUANT backend"
git remote add origin https://github.com/YOURUSERNAME/apexquant-backend.git
git push -u origin main
```

---

## STEP 1C — Deploy on Railway (Free)

1. Go to railway.app
2. Sign up with GitHub (free)
3. Click "New Project"
4. Choose "Deploy from GitHub repo"
5. Select "apexquant-backend"
6. Railway auto-detects Node.js and deploys ✅

---

## STEP 1D — Add Environment Variables on Railway

In your Railway project:
1. Click your service
2. Go to "Variables" tab
3. Add these one by one:

```
PORT = 3001
ANTHROPIC_API_KEY = (get free at console.anthropic.com)
TWELVE_DATA_KEY   = (get free at twelvedata.com)
ALPHA_VANTAGE_KEY = (get free at alphavantage.co)
FRONTEND_URL      = * (allow all for now)
```

NOTE: The app works WITHOUT API keys too.
Crypto prices come from CoinGecko (no key needed).
Forex uses simulated prices until you add Twelve Data key.

---

## STEP 1E — Get Your Backend URL

After Railway deploys:
1. Click your service → "Settings"
2. Under "Domains" → click "Generate Domain"
3. You get a URL like: https://apexquant-backend.up.railway.app

TEST IT: Open that URL in your phone browser.
You should see: { "status": "APEX QUANT LIVE", ... }

SAVE THIS URL — you need it for Step 5 (Frontend)

---

## FREE API KEYS (Get These Now)

### Twelve Data (Forex prices)
1. Go to twelvedata.com
2. Sign up free
3. Copy your API key from dashboard
4. Free tier: 800 requests/day ✅

### Alpha Vantage (Stock prices)
1. Go to alphavantage.co
2. Click "Get Free API Key"
3. Copy your key
4. Free tier: 25 requests/day ✅

### Anthropic (AI write-ups)
1. Go to console.anthropic.com
2. Sign up → go to "API Keys"
3. Create a new key
4. New accounts get free credits ✅

### CoinGecko (Crypto)
- NO KEY NEEDED ✅
- Completely free

---

## WHAT HAPPENS WHEN IT'S LIVE

Every 15 minutes automatically:
- Scans all 8 markets
- Checks HTF bias + Fibonacci
- Scores confluence (needs 7+/10 to pass)
- Broadcasts signal to your phone via WebSocket

Every 30 seconds:
- Live price updates sent to frontend

---

## NEXT STEP
Once Railway is live and you have your URL,
tell me and we move to Step 2:
Connecting real market data + OHLC candles
for proper multi-timeframe analysis.
